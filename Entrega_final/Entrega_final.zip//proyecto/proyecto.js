//-------------------Formateo en pesos--------------------------------

//Función para agregar comas como separadores de miles.
function comas(numero) {
  return numero.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

//Función que se activa cada vez que el usuario ingresa un valor en el campo de entrada del precio
function formateoPesos() {
  //Se btiene el valor ingresado por el usuario en el campo de entrada con el id productoPrecio y lo almacena en la variable precio
  let precio = document.getElementById("productoPrecio").value;

  //Se elimina cualquier caracter que no sea un número del valor ingresado
  precio = precio.replace(/[^0-9]/g, "");

  //La función comas formatea el número con comas para la separación de miles. El valor formateado se guarda en la variable formateo
  let formateo = comas(precio);

  //Se le agrega el símbolo de la moneda "$" al valor formateado
  formateo = "$" + formateo;

  //El valor formateado se muestra de nuevo en el campo del precio, reemplazando el valor ingresado al inicio
  document.getElementById("productoPrecio").value = formateo;
}

//----------------------Seleccion de la imagen registro------------------

function mostrarImagen() {
  // Obtener el elemento de select
  let select = document.getElementById("imagenRegistro");

  // Obtener el valor seleccionado (nombre de la imagen)
  let nombreImagen = select.value;

  // Obtener el elemento de la imagen predeterminada
  let imagen = document.getElementById("imagenPredeterminada");

  // Ruta de la carpeta de las imagenes
  let rutaCarpeta = "./images/";

  // Se completa la ruta de la imagen seleccionada
  let rutaImagen = rutaCarpeta + nombreImagen;

  // Se establece la ruta de la imagen seleccionada como atributo src de la etiqueta img
  imagen.src = rutaImagen;
}

//----------------------------Validacion del registro del producto------------------

function validarFormulario() {
  // Se obtienen los valores de los campos obligatorios del formulario
  let nombreProducto = document.getElementById("nombreRegistro").value;
  let codigoProducto = document.getElementById("codigoRegistro").value;
  let imagenSeleccionada = document.getElementById("imagenRegistro").value;
  let precioProducto = document.getElementById("productoPrecio").value;
  let categoriaProducto = document.getElementById("categoriaRegistro").value;

  // Validar que el nombre del producto no esté vacío y no supere los 20 caracteres
  if (nombreProducto.trim() == "" || nombreProducto.length > 20) {
    mostrarMensajeError();
    window.location.href = "./vista_indicaciones.html";
    return false; // Evitar el envío del formulario
  }

  // Validar que el código del producto cumpla con los requisitos
  let regexCodigo = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d.*\d)[A-Za-z\d]{8,}$/;
  if (!regexCodigo.test(codigoProducto)) {
    mostrarMensajeError();
    window.location.href = "./vista_indicaciones.html";
    return false; // Evitar el envío del formulario
  }

  // Validar que se haya seleccionado una imagen
  if (imagenSeleccionada.trim() === "") {
    mostrarMensajeError();
    window.location.href = "./vista_indicaciones.html";
    return false; // Evitar el envío del formulario
  }

  // Validar que se haya ingresado un precio
  if (precioProducto.trim() === "") {
    mostrarMensajeError();
    window.location.href = "./vista_indicaciones.html";
    return false; // Evitar el envío del formulario
  }

  // Validar que se haya seleccionado una categoría
  if (categoriaProducto.trim() === "") {
    mostrarMensajeError();
    window.location.href = "./vista_indicaciones.html";
    return false; // Evitar el envío del formulario
  }

  // Si todos los campos son válidos, permitir el envío del formulario y redirigir al usuario a la vista de productos
  return true;
}
function mostrarMensajeError() {
  // Mostrar el mensaje de error como una ventana emergente
  alert("Ups, algo salió mal, serás redirigido a la página de indicaciones.");
}

//-----------------------------------Redirigir a registro (vista de indicaciones)--------------------------------------------

function redirigirARegistro() {
  window.location.href = "./vista_registro.html";
}

//----------------------------------Tarjetas y paginación de la vista de productos---------------------------------------------

let paginaActual = 1;
const productosPorPagina = 15;

//Arreglo de objetos de los productos
let products = [
  {
    imagen: "./images/camisa_de_vestir.jpg",
    nombre: "Camisa de Vestir",
    categoria: "Elegante",
    precio: 55000,
    talla: "M",
    sexo: "Masculino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/vestido_de_gala.png",
    nombre: "Vestido de Gala",
    categoria: "Elegante",
    precio: 75000,
    talla: "L",
    sexo: "Femenino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/pantalones_vaqueros.jpg",
    nombre: "Pantalones Vaqueros",
    categoria: "Casual",
    precio: 45000,
    talla: "S",
    sexo: "Masculino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/blusa_floral.jpg",
    nombre: "Blusa Floral",
    categoria: "Casual",
    precio: 35000,
    talla: "M",
    sexo: "Femenino",
    temporada: "Verano",
  },
  {
    imagen: "./images/vestido_fiesta.jpg",
    nombre: "Vestido de Fiesta",
    categoria: "Elegante",
    precio: 85000,
    talla: "M",
    sexo: "Femenino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/camiseta_deportiva.png",
    nombre: "Camiseta Deportiva",
    categoria: "Deportivo",
    precio: 30000,
    talla: "L",
    sexo: "Masculino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/chaqueta_cuero.jpg",
    nombre: "Chaqueta de Cuero",
    categoria: "Casual",
    precio: 120000,
    talla: "M",
    sexo: "Unisex",
    temporada: "Uso general",
  },
  {
    imagen: "./images/pantalones_yoga.jpg",
    nombre: "Pantalones de Yoga",
    categoria: "Deportivo",
    precio: 40000,
    talla: "S",
    sexo: "Unisex",
    temporada: "Uso general",
  },
  {
    imagen: "./images/abrigo_invernal.png",
    nombre: "Abrigo Invernal",
    categoria: "Casual",
    precio: 150000,
    talla: "L",
    sexo: "Unisex",
    temporada: "Invierno",
  },
  {
    imagen: "./images/falda_mezclilla.jpg",
    nombre: "Falda de Mezclilla",
    categoria: "Casual",
    precio: 60000,
    talla: "M",
    sexo: "Femenino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/polo_estampado.png",
    nombre: "Polo Estampado",
    categoria: "Casual",
    precio: 25000,
    talla: "S",
    sexo: "Unisex",
    temporada: "Uso general",
  },
  {
    imagen: "./images/vestido_bohemio.jpg",
    nombre: "Vestido Bohemio",
    categoria: "Casual",
    precio: 70000,
    talla: "L",
    sexo: "Femenino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/camisa_rayas.jpg",
    nombre: "Camisa a Rayas",
    categoria: "Casual",
    precio: 35000,
    talla: "M",
    sexo: "Unisex",
    temporada: "Uso general",
  },
  {
    imagen: "./images/abrigo_lana.jpg",
    nombre: "Abrigo de Lana",
    categoria: "Casual",
    precio: 130000,
    talla: "XL",
    sexo: "Femenino",
    temporada: "Invierno",
  },
  {
    imagen: "./images/traje_baño.jpg",
    nombre: "Traje de Baño",
    categoria: "Deportivo",
    precio: 55000,
    talla: "M",
    sexo: "Masculino",
    temporada: "Verano",
  },
  {
    imagen: "./images/vestido_verano.jpg",
    nombre: "Vestido de Verano",
    categoria: "Casual",
    precio: 45000,
    talla: "S",
    sexo: "Femenino",
    temporada: "Verano",
  },
  {
    imagen: "./images/chaqueta_acolchada.jpg",
    nombre: "Chaqueta Acolchada",
    categoria: "Deportivo",
    precio: 95000,
    talla: "L",
    sexo: "Masculino",
    temporada: "Invierno",
  },
  {
    imagen: "./images/top_encaje.jpg",
    nombre: "Top de Encaje",
    categoria: "Casual",
    precio: 60000,
    talla: "M",
    sexo: "Femenino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/pantalon_vestir.jpg",
    nombre: "Pantalones de Vestir",
    categoria: "Elegante",
    precio: 50000,
    talla: "S",
    sexo: "Masculino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/sudadera.jpg",
    nombre: "Sudadera",
    categoria: "Deportivo",
    precio: 40000,
    talla: "M",
    sexo: "Unisex",
    temporada: "Uso general",
  },
  {
    imagen: "./images/camiseta_cuadros.jpg",
    nombre: "Camiseta a Cuadros",
    categoria: "Casual",
    precio: 30000,
    talla: "L",
    sexo: "Unisex",
    temporada: "Uso general",
  },
  {
    imagen: "./images/vestido_coctel.jpg",
    nombre: "Vestido de Cóctel",
    categoria: "Elegante",
    precio: 80000,
    talla: "M",
    sexo: "Femenino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/pantalon_cargo.jpg",
    nombre: "Pantalón de Cargo",
    categoria: "Casual",
    precio: 65000,
    talla: "L",
    sexo: "Masculino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/bufanda_lana.jpg",
    nombre: "Bufanda de Lana",
    categoria: "Casual",
    precio: 35000,
    talla: "Única",
    sexo: "Unisex",
    temporada: "Uso general",
  },
  {
    imagen: "./images/gorra_deportiva.jpg",
    nombre: "Gorra Deportiva",
    categoria: "Deportivo",
    precio: 25000,
    talla: "Única",
    sexo: "Unisex",
    temporada: "Uso general",
  },
  {
    imagen: "./images/vestido_novia.jpg",
    nombre: "Vestido de Novia",
    categoria: "Elegante",
    precio: 150000,
    talla: "M",
    sexo: "Femenino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/chaqueta_vaquera.jpg",
    nombre: "Chaqueta Vaquera",
    categoria: "Casual",
    precio: 85000,
    talla: "M",
    sexo: "Femenino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/chandal.jpg",
    nombre: "Chándal",
    categoria: "Deportivo",
    precio: 55000,
    talla: "L",
    sexo: "Masculino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/bañador.jpg",
    nombre: "Bañador",
    categoria: "Deportivo",
    precio: 45000,
    talla: "M",
    sexo: "Femenino",
    temporada: "Verano",
  },
  {
    imagen: "./images/pijama_algodon.jpg",
    nombre: "Pijama de Algodón",
    categoria: "Casual",
    precio: 40000,
    talla: "M",
    sexo: "Femenino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/jersey_punto.jpg",
    nombre: "Jersey de Punto",
    categoria: "Casual",
    precio: 60000,
    talla: "L",
    sexo: "Unisex",
    temporada: "Invierno",
  },
  {
    imagen: "./images/chaleco_acolchado.jpg",
    nombre: "Chaleco Acolchado",
    categoria: "Casual",
    precio: 75000,
    talla: "M",
    sexo: "Unisex",
    temporada: "Invierno",
  },
  {
    imagen: "./images/shorts.jpg",
    nombre: "Shorts",
    categoria: "Casual",
    precio: 30000,
    talla: "S",
    sexo: "Masculino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/falda_lapiz.jpg",
    nombre: "Falda Lápiz",
    categoria: "Elegante",
    precio: 55000,
    talla: "S",
    sexo: "Femenino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/camisa_hawaiana.jpg",
    nombre: "Camisa Hawaiana",
    categoria: "Casual",
    precio: 45000,
    talla: "M",
    sexo: "Masculino",
    temporada: "Verano",
  },
  {
    imagen: "./images/vestido_playa.jpg",
    nombre: "Vestido de Playa",
    categoria: "Casual",
    precio: 65000,
    talla: "M",
    sexo: "Femenino",
    temporada: "Verano",
  },
  {
    imagen: "./images/chaqueta_punto.jpg",
    nombre: "Chaqueta de Punto",
    categoria: "Casual",
    precio: 70000,
    talla: "L",
    sexo: "Unisex",
    temporada: "Uso general",
  },
  {
    imagen: "./images/sombrero_paja.jpeg",
    nombre: "Sombrero de Paja",
    categoria: "Accesorio",
    precio: 25000,
    talla: "Única",
    sexo: "Unisex",
    temporada: "Uso general",
  },
  {
    imagen: "./images/abrigo_cuadros.jpg",
    nombre: "Abrigo de Cuadros",
    categoria: "Casual",
    precio: 120000,
    talla: "M",
    sexo: "Unisex",
    temporada: "Invierno",
  },
  {
    imagen: "./images/bata_baño.jpg",
    nombre: "Bata de Baño",
    categoria: "Casual",
    precio: 45000,
    talla: "L",
    sexo: "Unisex",
    temporada: "Uso general",
  },
  {
    imagen: "./images/polo_corta.jpg",
    nombre: "Polo Manga Corta",
    categoria: "Casual",
    precio: 35000,
    talla: "M",
    sexo: "Masculino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/pantalon_pana.jpg",
    nombre: "Pantalón de Pana",
    categoria: "Casual",
    precio: 60000,
    talla: "L",
    sexo: "Masculino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/gorro_invierno.jpg",
    nombre: "Gorro de Invierno",
    categoria: "Casual",
    precio: 25000,
    talla: "Única",
    sexo: "Unisex",
    temporada: "Invierno",
  },
  {
    imagen: "./images/blazer.jpg",
    nombre: "Blazer",
    categoria: "Elegante",
    precio: 90000,
    talla: "M",
    sexo: "Masculino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/gorra_beisbol.jpg",
    nombre: "Gorra de Béisbol",
    categoria: "Deportivo",
    precio: 20000,
    talla: "Única",
    sexo: "Unisex",
    temporada: "Uso general",
  },
  {
    imagen: "./images/bermuda.jpg",
    nombre: "Bermuda",
    categoria: "Casual",
    precio: 40000,
    talla: "L",
    sexo: "Masculino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/camisa_larga.jpg",
    nombre: "Camisa Manga Larga",
    categoria: "Casual",
    precio: 45000,
    talla: "XL",
    sexo: "Masculino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/hoodie.jpg",
    nombre: "Hoodie",
    categoria: "Casual",
    precio: 55000,
    talla: "M",
    sexo: "Unisex",
    temporada: "Uso general",
  },
  {
    imagen: "./images/pantalon_slim.jpg",
    nombre: "Pantalón Slim",
    categoria: "Casual",
    precio: 70000,
    talla: "S",
    sexo: "Masculino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/blusa_satin.jpg",
    nombre: "Blusa de Satín",
    categoria: "Elegante",
    precio: 48000,
    talla: "M",
    sexo: "Femenino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/chaqueta_bomber.jpg",
    nombre: "Chaqueta Bomber",
    categoria: "Deportivo",
    precio: 80000,
    talla: "L",
    sexo: "Masculino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/blusa_algodon.png",
    nombre: "Blusa de Algodón",
    categoria: "Casual",
    precio: 45000,
    talla: "M",
    sexo: "Femenino",
    temporada: "Uso general",
  },
  {
    imagen: "./images/blusa_cropped.jpg",
    nombre: "Blusa Cropped",
    categoria: "Casual",
    precio: 40000,
    talla: "S",
    sexo: "Femenino",
    temporada: "Uso general",
  },
];

//Funcion para mostrar los productos
function displayProducts(pagina) {
  //Se calcula el indice de inicio y el indice de final para obtener la parte del arreglo que está en la página actual.
  const comienzo = (pagina - 1) * productosPorPagina;
  const final = comienzo + productosPorPagina;
  const productosAmostrar = products.slice(comienzo, final);

  //Se limpia el contenedor de la muestra de productos
  const contenedor = document.getElementById("contenedor-productos");
  contenedor.innerHTML = "";

  //Se recorre el arreglo de los productos
  productosAmostrar.forEach((producto) => {
    //Se crea un div para cada producto del arreglo y se muestran sus atributos
    const carta = document.createElement("div");
    carta.classList.add("producto-carta");
    carta.innerHTML = `
                    <img src="${producto.imagen}" alt="${producto.nombre}">
                    <p class="nombre"> ${producto.nombre}</p>
                    <p><strong>Categoría:</strong> ${producto.categoria}</p>
                    <p><strong>Talla:</strong> ${producto.talla}</p>
                    <p><strong>Género:</strong> ${producto.sexo}</p>
                    <p><strong>Temporada:</strong> ${producto.temporada}</p>
                    <p class="precio"> $${producto.precio}</p>
                    <button class="boton-comprar">Comprar</button>
                `;
    contenedor.appendChild(carta);
  });

  // Actualizar el nuemro de la página actual
  document.getElementById(
    "numero-pagina-actual"
  ).textContent = `${paginaActual}`;
}

//Funcion para pasar a la siguiente página
function PaginaSiguiente() {
  //Se calcula el total de paginas para mostrar todos los productos (el Math.ceil redonde hacia arriba cuando el numero de productos no es exacto)
  const totalPaginas = Math.ceil(products.length / productosPorPagina);

  //Si la pagina actual es menor al total de paginas entonces se pasa a la siguiente pagina y se habilita el boton de anterior
  if (paginaActual < totalPaginas) {
    paginaActual++;
    displayProducts(paginaActual);
    document
      .getElementById("boton-pagina-anterior")
      .removeAttribute("disabled");
  }

  //Si la pagina actual es la misma que el total, se desabilita el boton de siguiente
  if (paginaActual === totalPaginas) {
    document
      .getElementById("boton-pagina-siguiente")
      .setAttribute("disabled", "disabled");
  }
}

//Funcion para pasar a la pagina anterior
function PaginaAnterior() {
  //Si la pagina actual es mayor que 1, entonces se devuelve una pagina y se habilita el boton de pagina sigueinte
  if (paginaActual > 1) {
    paginaActual--;
    displayProducts(paginaActual);
    document
      .getElementById("boton-pagina-siguiente")
      .removeAttribute("disabled");
  }

  //Si la pagina actual es igual a la primera pagina, se desabilita el boton de pagina anterior
  if (paginaActual === 1) {
    document
      .getElementById("boton-pagina-anterior")
      .setAttribute("disabled", "disabled");
  }
}

// Mostrar los productos de la primera página al cargar la página
displayProducts(paginaActual);

//-------Funcion para redirigir a la busqueda de productos (vista productos)-----------------------

function redirigirABusqueda() {
  window.location.href = "./vista_buscador.html";
}

//-------Funcion para redirigir a productos (vista buscador)-----------------------
function redirigirAProductos() {
  window.location.href = "./vista_productos.html";
}

//-------Funcion para la busqueda de productos (vista buscador)-----------------------

// Función para simular la obtención de datos con una promesa
function obtenerDatosConPromesa() {
  return new Promise((resolve) => {
    // Simular una demora de 2 segundos para obtener los datos
    setTimeout(() => {
      resolve(products); // Se resuelve la promesa con el arreglo de los productos
    }, 2000);
  });
}

// Función para mostrar el mensaje de "Cargando..."
function mostrarMensajeCargando() {
  // Obtener el contenedor de resultados
  const resultadosBusqueda = document.getElementById("resultadosBusqueda");
  // Mostrar el mensaje de "Cargando..."
  resultadosBusqueda.innerHTML = "<p>Cargando...</p>";
}

// Función para realizar la búsqueda de productos después de hacer clic en el botón
function realizarBusqueda() {
  // Mostrar el mensaje de "Cargando..."
  mostrarMensajeCargando();

  // Simular la obtención de datos con una promesa
  obtenerDatosConPromesa()
    //Cuando se resuelve la promesa, se le realizan los filtros seleccionados al arreglo
    .then((productos) => {
      const categoria = document.getElementById("categoriaFiltro").value;
      const talla = document.getElementById("tallaFiltro").value;
      const genero = document.getElementById("generoFiltro").value;
      const temporada = document.getElementById("temporadaFiltro").value;

      //Arreglo productosFiltrados almacena los productos cumplan con los filtros seleccioandos, se usa la funcion filter para cada producto del arreglo
      const productosFiltrados = productos.filter((producto) => {
        return (
          //primero se verifica si se seleccionó el atributo en los filtros y dependiendo de eso, se compara el atributo seleccioando en el filtro con el atributo del producto para ver si coinciden
          (!categoria || producto.categoria === categoria) &&
          (!talla || producto.talla === talla) &&
          (!genero || producto.sexo === genero) &&
          (!temporada || producto.temporada === temporada)
        );
      });

      // Crear la tabla de resultados
      const resultadosBusqueda = document.getElementById("resultadosBusqueda");
      resultadosBusqueda.innerHTML = "";

      //Si el arreglo de los objetos que pasaron el filtro tiene al menos 1 elemento entonces se crea la tabla de resultados
      if (productosFiltrados.length > 0) {
        const tabla = document.createElement("table");
        tabla.classList.add("tabla-productos");

        // Se crean los encabezados de la tabla
        const encabezado = document.createElement("thead");
        const columna = document.createElement("tr");
        columna.innerHTML = `
          <th>Imagen</th>
          <th>Nombre</th>
          <th>Categoría</th>
          <th>Talla</th>
          <th>Género</th>
          <th>Temporada</th>
          <th>Precio</th>
          <th>¿interesado(a)?</th>
        `;
        encabezado.appendChild(columna);
        tabla.appendChild(encabezado);

        // Se crean las filas de la tabla
        const cuerpo = document.createElement("tbody");
        //Se recorre el arreglo de los productos filtrados y por cada producto se crea una fila
        productosFiltrados.forEach((producto) => {
          const fila = document.createElement("tr");
          //En cada fila se crean celdas para cada uno de los atributos
          fila.innerHTML = `
    
            <td><img src="${producto.imagen}" alt="${producto.nombre}" class="imagen-tabla"></td>
            <td>${producto.nombre}</td>
            <td>${producto.categoria}</td>
            <td>${producto.talla}</td>
            <td>${producto.sexo}</td>
            <td>${producto.temporada}</td>
            <td>$${producto.precio} COP</td>
            <td><button class="boton-comprar-busqueda">Comprar</button></td>
          `;
          //Se añaden las filas al cuerpo una por una
          cuerpo.appendChild(fila);
        });
        //Se añaden todas las filas a la tabla
        tabla.appendChild(cuerpo);

        // Se inserta la tabla en el contenedor de resultados
        resultadosBusqueda.appendChild(tabla);
      } else {
        //Si no se encuentran productos con los filtros seleccionados se imprime un mensaje
        resultadosBusqueda.innerHTML =
          "<p>No se encontraron productos que coincidan con los filtros.</p>";
      }
    })
    //Si hubo un error con la promesa entonces se imprime un mensaje de error
    .catch((error) => {
      console.error("Error al obtener datos:", error);
    });

  return false; // Evitar que el formulario se envíe
}
